<?php
/*
Plugin Name: GymBase Theme Galleries
Plugin URI: https://1.envato.market/quanticalabs-portfolio
Description: GymBase Theme Galleries Plugin
Author: QuanticaLabs
Author URI: https://1.envato.market/quanticalabs
Version: 1.1
Text Domain: gymbase_galleries
*/

//translation
function gymbase_gallery_load_textdomain()
{
	load_plugin_textdomain("gymbase_gallery", false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'gymbase_gallery_load_textdomain');
//custom post type - galleries
if(is_admin())
{
	function gymbase_gallery_admin_menu()
	{
		$permalinks_page = add_submenu_page('edit.php?post_type=gymbase_gallery', __('Permalink', 'gymbase_galleries'), __('Permalink', 'gymbase_galleries'), 'manage_options', 'gallery_permalink', 'gymbase_gallery_permalink');
	}
	add_action("admin_menu", "gymbase_gallery_admin_menu");
	
	function gymbase_gallery_permalink()
	{
		$message = "";
		if(isset($_POST["action"]) && $_POST["action"]=="save_gallery_permalink")
			$message = __("Options saved!", "gymbase_gallery");
		$gallery_permalink = array(
			"slug" => 'gymbase_galleries',
			"label_singular" => __("Gallery", 'gymbase_galleries'),
			"label_plural" => __("Galleries", 'gymbase_galleries')
		);
		$gallery_permalink = array_merge($gallery_permalink, (array)get_option("gallery_permalink"));
		
		require_once("admin/admin-page-permalink.php");
	}
}
function gymbase_gallery_init()
{
	$gallery_permalink = array(
		"slug" => 'gymbase_galleries',
		"label_singular" => __("Gallery", 'gymbase_galleries'),
		"label_plural" => __("Galleries", 'gymbase_galleries')
	);
	if(isset($_POST["action"]) && $_POST["action"]=="save_gallery_permalink")
	{
		$gallery_permalink = array_merge($gallery_permalink, (array)get_option("gallery_permalink"));
		$slug_old = $gallery_permalink["slug"];
		$gallery_permalink = array(
			"slug" => (!empty($_POST["slug"]) ? sanitize_title($_POST["slug"]) : "gymbase_gallery"),
			"label_singular" => (!empty($_POST["label_singular"]) ? $_POST["label_singular"] : __("Gallery", "gymbase_gallery")),
			"label_plural" => (!empty($_POST["label_plural"]) ? $_POST["label_plural"] : __("Galleries", "gymbase_gallery"))
		);
		update_option("gallery_permalink", $gallery_permalink);
		if($slug_old!=$_POST["slug"])
		{
			delete_option('rewrite_rules');
		}
	}
	$gallery_permalink = array_merge($gallery_permalink, (array)get_option("gallery_permalink"));
	$labels = array(
		'name' => $gallery_permalink['label_plural'],
		'singular_name' => $gallery_permalink['label_singular'],
		'add_new' => _x('Add New', $gallery_permalink["slug"], 'gymbase_galleries'),
		'add_new_item' => sprintf(__('Add New %s' , 'gymbase_galleries') , $gallery_permalink['label_singular']),
		'edit_item' => sprintf(__('Edit %s', 'gymbase_galleries'), $gallery_permalink['label_singular']),
		'new_item' => sprintf(__('New %s', 'gymbase_galleries'), $gallery_permalink['label_singular']),
		'all_items' => sprintf(__('All %s', 'gymbase_galleries'), $gallery_permalink['label_plural']),
		'view_item' => sprintf(__('View %s', 'gymbase_galleries'), $gallery_permalink['label_singular']),
		'search_items' => sprintf(__('Search %s', 'gymbase_galleries'), $gallery_permalink['label_plural']),
		'not_found' =>  sprintf(__('No %s found', 'gymbase_galleries'), strtolower($gallery_permalink['label_plural'])),
		'not_found_in_trash' => sprintf(__('No %s found in Trash', 'gymbase_galleries'), strtolower($gallery_permalink['label_plural'])), 
		'parent_item_colon' => '',
		'menu_name' => $gallery_permalink['label_plural']
	);
	$args = array(  
		"labels" => $labels, 
		"public" => true,  
		"show_ui" => true,  
		"capability_type" => "post",  
		"menu_position" => 20,
		"hierarchical" => false,  
		"rewrite" => array("slug" => $gallery_permalink["slug"]),
		"supports" => array("title", "editor", "excerpt", "thumbnail", "page-attributes")  
	);
	register_post_type("gymbase_gallery", $args);
	register_taxonomy("gymbase_gallery_category", array("gymbase_gallery"), array("label" => __("Categories", 'gymbase_galleries'), "singular_label" => __("Category", 'gymbase_galleries'), "rewrite" => true));
}  
add_action("init", "gymbase_gallery_init");

//Adds a box to the main column on the Gallery edit screens
function gymbase_add_gallery_custom_box() 
{
    add_meta_box( 
        "gallery_config",
        __("Options", 'gymbase_galleries'),
        "gymbase_inner_gallery_custom_box",
        "gymbase_gallery",
		"normal",
		"high"
    );
}
add_action("add_meta_boxes", "gymbase_add_gallery_custom_box");

// Prints the box content
function gymbase_inner_gallery_custom_box($post) 
{
	//Use nonce for verification
	wp_nonce_field(plugin_basename( __FILE__ ), "gymbase_gallery_noncename");

	//The actual fields for data entry
	$external_url_target = get_post_meta($post->ID, "external_url_target", true);
	echo '
	<table>
		<tr>
			<td>
				<label for="subtitle">' . __('Subtitle', 'gymbase_galleries') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="subtitle" name="subtitle" value="' . esc_attr(get_post_meta($post->ID, "subtitle", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="gallery_video_url">' . __('Video URL (optional)', 'gymbase_galleries') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="gallery_video_url" name="gallery_video_url" value="' . esc_attr(get_post_meta($post->ID, "video_url", true)) . '" />
				<span class="description">' . __('For Vimeo please use https://vimeo.com/%video_id% For YouTube: https://www.youtube.com/watch?v=%video_id%', 'gymbase_galleries') . '</span>
			</td>
		</tr>
		<tr>
			<td>
				<label for="gallery_iframe_url">' . __('Ifame URL (optional)', 'gymbase_galleries') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="gallery_iframe_url" name="gallery_iframe_url" value="' . esc_attr(get_post_meta($post->ID, "iframe_url", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="gallery_external_url">' . __('External URL (optional)', 'gymbase_galleries') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="gallery_external_url" name="gallery_external_url" value="' . esc_attr(get_post_meta($post->ID, "external_url", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="gallery_external_url_target">' . __('External URL target', 'gymbase_galleries') . ':</label>
			</td>
			<td>
				<select id="gallery_external_url_target" name="gallery_external_url_target">
					<option value="same_window"' . ($external_url_target=="same_window" ? ' selected="selected"' : '') . '>' . __('same window', 'gymbase_galleries') . '</option>
					<option value="new_window"' . ($external_url_target=="new_window" ? ' selected="selected"' : '') . '>' . __('new window', 'gymbase_galleries') . '</option>
				</select>
			</td>
		</tr>
	</table>
	';
}

//When the post is saved, saves our custom data
function gymbase_save_gallery_postdata($post_id) 
{
	//verify if this is an auto save routine. 
	//if it is our form has not been submitted, so we dont want to do anything
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) 
		return;

	//verify this came from the our screen and with proper authorization,
	//because save_post can be triggered at other times
	if(!isset($_POST['gymbase_gallery_noncename']) || !wp_verify_nonce($_POST['gymbase_gallery_noncename'], plugin_basename( __FILE__ )))
		return;


	//Check permissions
	if(!current_user_can('edit_post', $post_id))
		return;

	//OK, we're authenticated: we need to find and save the data
	update_post_meta($post_id, "subtitle", $_POST["subtitle"]);
	update_post_meta($post_id, "video_url", $_POST["gallery_video_url"]);
	update_post_meta($post_id, "iframe_url", $_POST["gallery_iframe_url"]);
	update_post_meta($post_id, "external_url", $_POST["gallery_external_url"]);
	update_post_meta($post_id, "external_url_target", $_POST["gallery_external_url_target"]);
}
add_action("save_post", "gymbase_save_gallery_postdata");

//custom gallery items list
function gymbase_gallery_edit_columns($columns)
{
	$columns = array(  
		"cb" => "<input type=\"checkbox\" />",  
		"title" => _x('Gallery Item', 'post type singular name', 'gymbase_galleries'),   
		"video_url" => __('Video URL', 'gymbase_galleries'),
		"iframe_url" => __('Iframe URL', 'gymbase_galleries'),
		"external_url" => __('External URL', 'gymbase_galleries'),
		"gymbase_gallery_category" => __('Categories', 'gymbase_galleries'),
		"date" => __('Date', 'gymbase_galleries')
	);    

	return $columns;  
}  
add_filter("manage_edit-gymbase_gallery_columns", "gymbase_gallery_edit_columns");

function manage_gymbase_gallery_posts_custom_column($column)
{
	global $post;
	switch ($column)  
	{
		case "video_url":   
			echo get_post_meta($post->ID, "video_url", true);  
			break;
		case "iframe_url":   
			echo get_post_meta($post->ID, "iframe_url", true);  
			break;
		case "external_url":   
			echo get_post_meta($post->ID, "external_url", true);  
			break;
		case "gymbase_gallery_category":
			$gallery_category_list = (array)get_the_terms($post->ID, "gymbase_gallery_category");
			foreach($gallery_category_list as $gallery_category)
			{
				if(empty($gallery_category->slug))
					continue;
				echo '<a href="' . esc_url(admin_url("edit.php?post_type=gymbase_gallery&gymbase_gallery_category=" . $gallery_category->slug)) . '">' . $gallery_category->name . '</a>' . (end($gallery_category_list)!=$gallery_category ? ", " : "");;
			}
			break;
	}  
}
add_action("manage_gymbase_gallery_posts_custom_column", "manage_gymbase_gallery_posts_custom_column");

//gallery shortcode
add_shortcode("gymbase_gallery", "gymbase_gallery_shortcode");

//visual composer
function gymbase_gallery_vc_init()
{
	if(is_plugin_active("js_composer/js_composer.php") && function_exists('vc_map'))
	{
		//get gallery items list
		$gallery_items_list = get_posts(array(
			'posts_per_page' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
			'post_type' => 'gymbase_gallery'
		));
		$gallery_items_array = array();
		$gallery_items_array[__("All", 'gymbase_galleries')] = "-";
		foreach($gallery_items_list as $gallery_item)
			$gallery_items_array[$gallery_item->post_title . " (id:" . $gallery_item->ID . ")"] = $gallery_item->ID;

		//get categories list
		$categories = get_terms("gymbase_gallery_category");
		$categories_array = array();
		$categories_array[__("All", 'gymbase_galleries')] = "";
		foreach($categories as $category) {
			$categories_array[$category->name] = $category->slug;
		}
		
		//image sizes
		$image_sizes_array = array();
		$image_sizes_array[__("Default", 'gymbase_galleries')] = "default";
		$image_sizes_array[__("full (original image resolution)", 'gymbase_galleries')] = "full";
		global $_wp_additional_image_sizes;
		foreach(get_intermediate_image_sizes() as $s) 
		{
			if(isset($_wp_additional_image_sizes[$s])) 
			{
				$width = intval($_wp_additional_image_sizes[$s]['width']);
				$height = intval($_wp_additional_image_sizes[$s]['height']);
			} 
			else
			{
				$width = get_option($s.'_size_w');
				$height = get_option($s.'_size_h');
			}
			$image_sizes_array[$s . " (" . $width . "x" . $height . ")"] = "gb_" . $s;
		}
		
		vc_map( array(
			"name" => __("Gallery", 'gymbase_galleries'),
			"base" => "gymbase_gallery",
			"class" => "",
			"controls" => "full",
			"show_settings_on_create" => true,
			"icon" => "icon-wpb-layer-gallery",
			"category" => __('GymBase', 'gymbase_galleries'),
			"params" => array(
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Display selected", 'medicenter_galleries'),
					"param_name" => "ids",
					"value" => $gallery_items_array
				),
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Category", 'gymbase_galleries'),
					"param_name" => "category",
					"value" => $categories_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order by", 'gymbase_galleries'),
					"param_name" => "order_by",
					"value" => array(__("Menu order", 'gymbase_galleries') => "menu_order", __("Title, menu order", 'gymbase_galleries') => "title,menu_order", __("Date", 'gymbase_galleries') => "date")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order", 'gymbase_galleries'),
					"param_name" => "order",
					"value" => array(__("ascending", 'gymbase_galleries') => "ASC", __("descending", 'gymbase_galleries') => "DESC")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Type", 'gymbase_galleries'),
					"param_name" => "type",
					"value" => array(__("List with details", 'gymbase_galleries') => "list_with_details", __("List", 'gymbase_galleries') => "list", __("Details", 'gymbase_galleries') => "details")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Layout", 'gymbase_galleries'),
					"param_name" => "layout",
					"value" => array(__("4 columns", 'gymbase_galleries') => "gallery-4-columns", __("3 columns", 'gymbase_galleries') => "gallery-3-columns", __("2 columns", 'gymbase_galleries') => "gallery-2-columns")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Layout type", 'gymbase_galleries'),
					"param_name" => "layout_type",
					"value" => array(__("Compact", 'gymbase_galleries') => "compact", __("Separate", 'gymbase_galleries') => "separate")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Featured image size", 'gymbase_galleries'),
					"param_name" => "featured_image_size",
					"value" => $image_sizes_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Link to single gallery page on image box", 'gymbase_galleries'),
					"param_name" => "image_box_link",
					"value" => array(__("Yes", 'gymbase_galleries') => 1, __("No", 'gymbase_galleries') => 0),
					"std" => 0
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Display title in details", 'gymbase_galleries'),
					"param_name" => "display_headers",
					"value" => array(__("Yes", 'gymbase_galleries') => 1, __("No", 'gymbase_galleries') => 0),
					"dependency" => Array('element' => "type", 'value' => array('list_with_details', 'details'))
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Display method", 'gymbase_galleries'),
					"param_name" => "display_method",
					"value" => array(__("Filters", 'gymbase_galleries') => 'dm_filters', __("Simple", 'gymbase_galleries') => 'dm_simple'),
					"dependency" => Array('element' => "type", 'value' => array('list_with_details', 'list'))
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("All filter label", 'gymbase_galleries'),
					"param_name" => "all_label",
					"value" => __("All Classes", 'gymbase_galleries'),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_filters')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Top margin", 'gymbase_galleries'),
					"param_name" => "top_margin",
					"value" => array(__("None", 'gymbase_galleries') => "none", __("Page (small)", 'gymbase_galleries') => "page-margin-top", __("Section (large)", 'gymbase_galleries') => "page-margin-top-section")
				),
				array(
					'type' => 'textfield',
					'heading' => __('Extra class name', 'gymbase_galleries'),
					'param_name' => 'el_class',
					'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'gymbase_galleries')
				)
			)
		));
	}
}
add_action("init", "gymbase_gallery_vc_init");
?>