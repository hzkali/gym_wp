<?php
/*
Plugin Name: GymBase Theme Trainers
Plugin URI: https://1.envato.market/quanticalabs-portfolio
Description: GymBase Theme Trainers Plugin
Author: QuanticaLabs
Author URI: https://1.envato.market/quanticalabs
Version: 1.1
Text Domain: gymbase_trainers
*/

//translation
function gymbase_trainers_load_textdomain()
{
	load_plugin_textdomain("gymbase_trainers", false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'gymbase_trainers_load_textdomain');
//custom post type - trainers
if(is_admin())
{
	function gymbase_trainers_admin_menu()
	{
		$permalinks_page = add_submenu_page('edit.php?post_type=trainers', __('Permalink', 'gymbase_trainers'), __('Permalink', 'gymbase_trainers'), 'manage_options', 'trainers_permalink', 'gymbase_trainers_permalink');
	}
	add_action("admin_menu", "gymbase_trainers_admin_menu");
	
	function gymbase_trainers_permalink()
	{
		$message = "";
		if(isset($_POST["action"]) && $_POST["action"]=="save_trainers_permalink")
			$message = __("Options saved!", "gymbase_trainers");
		$trainers_permalink = array(
			"slug" => 'trainers',
			"label_singular" => __("Trainer", 'gymbase_trainers'),
			"label_plural" => __("Trainers", 'gymbase_trainers')
		);
		$trainers_permalink = array_merge($trainers_permalink, (array)get_option("trainers_permalink"));
		
		require_once("admin/admin-page-permalink.php");
	}
}
function gymbase_trainers_init()
{
	$trainers_permalink = array(
		"slug" => 'trainers',
		"label_singular" => __("Trainer", 'gymbase_trainers'),
		"label_plural" => __("Trainers", 'gymbase_trainers')
	);
	if(isset($_POST["action"]) && $_POST["action"]=="save_trainers_permalink")
	{
		$trainers_permalink = array_merge($trainers_permalink, (array)get_option("trainers_permalink"));
		$slug_old = $trainers_permalink["slug"];
		$trainers_permalink = array(
			"slug" => (!empty($_POST["slug"]) ? sanitize_title($_POST["slug"]) : "trainers"),
			"label_singular" => (!empty($_POST["label_singular"]) ? $_POST["label_singular"] : __("Trainer", "gymbase_trainers")),
			"label_plural" => (!empty($_POST["label_plural"]) ? $_POST["label_plural"] : __("Trainers", "gymbase_trainers"))
		);
		update_option("trainers_permalink", $trainers_permalink);
		if($slug_old!=$_POST["slug"])
		{
			delete_option('rewrite_rules');
		}
	}
	$trainers_permalink = array_merge($trainers_permalink, (array)get_option("trainers_permalink"));
	$labels = array(
		'name' => $trainers_permalink['label_plural'],
		'singular_name' => $trainers_permalink['label_singular'],
		'add_new' => _x('Add New', $trainers_permalink["slug"], 'gymbase_trainers'),
		'add_new_item' => sprintf(__('Add New %s' , 'gymbase_trainers') , $trainers_permalink['label_singular']),
		'edit_item' => sprintf(__('Edit %s', 'gymbase_trainers'), $trainers_permalink['label_singular']),
		'new_item' => sprintf(__('New %s', 'gymbase_trainers'), $trainers_permalink['label_singular']),
		'all_items' => sprintf(__('All %s', 'gymbase_trainers'), $trainers_permalink['label_plural']),
		'view_item' => sprintf(__('View %s', 'gymbase_trainers'), $trainers_permalink['label_singular']),
		'search_items' => sprintf(__('Search %s', 'gymbase_trainers'), $trainers_permalink['label_plural']),
		'not_found' =>  sprintf(__('No %s found', 'gymbase_trainers'), strtolower($trainers_permalink['label_plural'])),
		'not_found_in_trash' => sprintf(__('No %s found in Trash', 'gymbase_trainers'), strtolower($trainers_permalink['label_plural'])), 
		'parent_item_colon' => '',
		'menu_name' => $trainers_permalink['label_plural']
	);
	$args = array(  
		"labels" => $labels, 
		"public" => true,  
		"show_ui" => true,  
		"capability_type" => "post",  
		"menu_position" => 20,
		"hierarchical" => false,  
		"rewrite" => array("slug" => $trainers_permalink["slug"]),
		"supports" => array("title", "editor", "excerpt", "thumbnail", "page-attributes")  
	);
	register_post_type("trainers", $args);
	register_taxonomy("trainers_category", array("trainers"), array("label" => __("Categories", 'gymbase_trainers'), "singular_label" => __("Category", 'gymbase_trainers'), "rewrite" => true));
}  
add_action("init", "gymbase_trainers_init");

//Adds a box to the right column and to the main column on the Trainers edit screens
function gymbase_add_trainers_custom_box() 
{
	add_meta_box( 
        "trainers_config",
        __("Options", 'gymbase_trainers'),
        "gymbase_inner_trainers_custom_box_main",
        "trainers",
		"normal",
		"high"
    );
}
add_action("add_meta_boxes", "gymbase_add_trainers_custom_box");

function gymbase_inner_trainers_custom_box_main($post)
{
	//Use nonce for verification
	wp_nonce_field(plugin_basename( __FILE__ ), "gymbase_trainers_noncename");
	
	//The actual fields for data entry
	$external_url_target = get_post_meta($post->ID, "external_url_target", true);
	echo '
	<table>
		<tr>
			<td>
				<label for="trainer_subtitle">' . __('Subtitle', 'gymbase_trainers') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="trainer_subtitle" name="trainer_subtitle" value="' . esc_attr(get_post_meta($post->ID, "subtitle", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="trainer_description">' . __('Description', 'gymbase_trainers') . ':</label>
			</td>
			<td>';
				$trainer_description = get_post_meta($post->ID, "trainer_description", true);
				$settings = array(
					'editor_height' => 300
				);
				wp_editor(!empty($trainer_description) ? $trainer_description : "", "trainer_description", $settings);
		echo '</td>
		</tr>
		<tr>
			<td>
				<label for="trainer_video_url">' . __('Video URL (optional)', 'gymbase_trainers') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="trainer_video_url" name="trainer_video_url" value="' . esc_attr(get_post_meta($post->ID, "video_url", true)) . '" />
				<span class="description">' . __('For Vimeo please use https://vimeo.com/%video_id% For YouTube: https://www.youtube.com/watch?v=%video_id%', 'gymbase_trainers') . '</span>
			</td>
		</tr>
		<tr>
			<td>
				<label for="trainer_iframe_url">' . __('Ifame URL (optional)', 'gymbase_trainers') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="trainer_iframe_url" name="trainer_iframe_url" value="' . esc_attr(get_post_meta($post->ID, "iframe_url", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="trainer_external_url">' . __('External URL (optional)', 'gymbase_trainers') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="trainer_external_url" name="trainer_external_url" value="' . esc_attr(get_post_meta($post->ID, "external_url", true)) . '" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="trainer_external_url_target">' . __('External URL target', 'gymbase_trainers') . ':</label>
			</td>
			<td>
				<select id="trainer_external_url_target" name="trainer_external_url_target">
					<option value="same_window"' . ($external_url_target=="same_window" ? ' selected="selected"' : '') . '>' . __('same window', 'gymbase_trainers') . '</option>
					<option value="new_window"' . ($external_url_target=="new_window" ? ' selected="selected"' : '') . '>' . __('new window', 'gymbase_trainers') . '</option>
				</select>
			</td>
		</tr>
	</table>';
}

//When the post is saved, saves our custom data
function gymbase_save_trainers_postdata($post_id) 
{
	//verify if this is an auto save routine. 
	//if it is our form has not been submitted, so we dont want to do anything
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) 
		return;

	//verify this came from the our screen and with proper authorization,
	//because save_post can be triggered at other times
	if(!isset($_POST['gymbase_trainers_noncename']) || !wp_verify_nonce($_POST['gymbase_trainers_noncename'], plugin_basename( __FILE__ )))
		return;


	//Check permissions
	if(!current_user_can('edit_post', $post_id))
		return;

	//OK, we're authenticated: we need to find and save the data
	update_post_meta($post_id, "subtitle", $_POST["trainer_subtitle"]);
	update_post_meta($post_id, "trainer_description", $_POST["trainer_description"]);
	update_post_meta($post_id, "video_url", $_POST["trainer_video_url"]);
	update_post_meta($post_id, "iframe_url", $_POST["trainer_iframe_url"]);
	update_post_meta($post_id, "external_url", $_POST["trainer_external_url"]);
	update_post_meta($post_id, "external_url_target", $_POST["trainer_external_url_target"]);
}
add_action("save_post", "gymbase_save_trainers_postdata");

function gymbase_trainers_edit_columns($columns)
{
	$columns = array(
			"cb" => "<input type=\"checkbox\" />",
			"title" => _x('Title', 'post type singular name', 'gymbase_trainers'),
			"video_url" => __('Video URL', 'gymbase_trainers'),
			"iframe_url" => __('Iframe URL', 'gymbase_trainers'),
			"external_url" => __('External URL', 'gymbase_trainers'),
			"trainers_category" => __('Categories', 'gymbase_trainers'),
			"date" => __('Date', 'gymbase_trainers')
	);

	return $columns;
}
add_filter("manage_edit-trainers_columns", "gymbase_trainers_edit_columns");

function manage_gymbase_trainers_posts_custom_column($column)
{
	global $post;
	switch ($column)
	{
		case "video_url":   
			echo get_post_meta($post->ID, "video_url", true);  
			break;
		case "iframe_url":   
			echo get_post_meta($post->ID, "iframe_url", true);  
			break;
		case "external_url":   
			echo get_post_meta($post->ID, "external_url", true);  
			break;
		case "trainers_category":
			$trainers_category_list = (array)get_the_terms($post->ID, "trainers_category");
			foreach($trainers_category_list as $trainers_category)
			{
				if(empty($trainers_category->slug))
					continue;
				echo '<a href="' . esc_url(admin_url("edit.php?post_type=trainers&trainers_category=" . $trainers_category->slug)) . '">' . $trainers_category->name . '</a>' . (end($trainers_category_list)!=$trainers_category ? ", " : "");;
			}
			break;
	}
}
add_action("manage_trainers_posts_custom_column", "manage_gymbase_trainers_posts_custom_column");

//trainers shortcode
add_shortcode("trainers", "gymbase_gallery_shortcode");

//visual composer
function gymbase_trainers_vc_init()
{
	if(is_plugin_active("js_composer/js_composer.php") && function_exists('vc_map'))
	{
		//get trainers list
		$trainers_list = get_posts(array(
			'posts_per_page' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
			'post_type' => 'trainers'
		));
		$trainers_array = array();
		$trainers_array[__("All", 'gymbase_trainers')] = "-";
		foreach($trainers_list as $trainer)
			$trainers_array[$trainer->post_title . " (id:" . $trainer->ID . ")"] = $trainer->ID;
			
		//get categories list
		$categories = get_terms("trainers_category");
		$categories_array = array();
		$categories_array[__("All", 'gymbase_trainers')] = "";
		foreach($categories as $category) {
			$categories_array[$category->name] = $category->slug;
		}
		
		//image sizes
		$image_sizes_array = array();
		$image_sizes_array[__("Default", 'gymbase_trainers')] = "default";
		$image_sizes_array[__("full (original image resolution)", 'gymbase_trainers')] = "full";
		global $_wp_additional_image_sizes;
		foreach(get_intermediate_image_sizes() as $s) 
		{
			if(isset($_wp_additional_image_sizes[$s])) 
			{
				$width = intval($_wp_additional_image_sizes[$s]['width']);
				$height = intval($_wp_additional_image_sizes[$s]['height']);
			} 
			else
			{
				$width = get_option($s.'_size_w');
				$height = get_option($s.'_size_h');
			}
			$image_sizes_array[$s . " (" . $width . "x" . $height . ")"] = "gb_" . $s;
		}
		
		vc_map( array(
			"name" => __("Trainers list", 'gymbase_trainers'),
			"base" => "trainers",
			"class" => "",
			"controls" => "full",
			"show_settings_on_create" => true,
			"icon" => "icon-wpb-layer-custom-post-type-list",
			"category" => __('GymBase', 'gymbase_trainers'),
			"params" => array(
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Display selected", 'gymbase_trainers'),
					"param_name" => "ids",
					"value" => $trainers_array
				),
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Category", 'gymbase_trainers'),
					"param_name" => "category",
					"value" => $categories_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order by", 'gymbase_trainers'),
					"param_name" => "order_by",
					"value" => array(__("Menu order", 'gymbase_trainers') => "menu_order", __("Title, menu order", 'gymbase_trainers') => "title,menu_order", __("Date", 'gymbase_trainers') => "date")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order", 'gymbase_trainers'),
					"param_name" => "order",
					"value" => array(__("ascending", 'gymbase_trainers') => "ASC", __("descending", 'gymbase_trainers') => "DESC")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Type", 'gymbase_trainers'),
					"param_name" => "type",
					"value" => array(__("List with details", 'gymbase_trainers') => "list_with_details", __("List", 'gymbase_trainers') => "list", __("Details", 'gymbase_trainers') => "details")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Layout", 'gymbase_trainers'),
					"param_name" => "layout",
					"value" => array(__("4 columns", 'gymbase_trainers') => "gallery-4-columns", __("3 columns", 'gymbase_trainers') => "gallery-3-columns", __("2 columns", 'gymbase_trainers') => "gallery-2-columns")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Layout type", 'gymbase_trainers'),
					"param_name" => "layout_type",
					"value" => array(__("Compact", 'gymbase_trainers') => "compact", __("Separate", 'gymbase_trainers') => "separate")
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Featured image size", 'gymbase_trainers'),
					"param_name" => "featured_image_size",
					"value" => $image_sizes_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Link to single trainer page on image box", 'gymbase_trainers'),
					"param_name" => "image_box_link",
					"value" => array(__("Yes", 'gymbase_trainers') => 1, __("No", 'gymbase_trainers') => 0),
					"std" => 0
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Display title in details", 'gymbase_trainers'),
					"param_name" => "display_headers",
					"value" => array(__("Yes", 'gymbase_trainers') => 1, __("No", 'gymbase_trainers') => 0),
					"dependency" => Array('element' => "type", 'value' => array('list_with_details', 'details'))
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Load content from description in details", 'gymbase_trainers'),
					"param_name" => "load_content_description",
					"value" => array(__("Yes", 'gymbase_trainers') => 1, __("No", 'gymbase_trainers') => 0),
					"dependency" => Array('element' => "type", 'value' => array('list_with_details', 'details'))
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Display method", 'gymbase_trainers'),
					"param_name" => "display_method",
					"value" => array(__("Filters", 'gymbase_trainers') => 'dm_filters', __("Simple", 'gymbase_trainers') => 'dm_simple'),
					"dependency" => Array('element' => "type", 'value' => array('list_with_details', 'list'))
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("All filter label", 'gymbase_trainers'),
					"param_name" => "all_label",
					"value" => "",
					"dependency" => Array('element' => "display_method", 'value' => 'dm_filters')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Top margin", 'gymbase_trainers'),
					"param_name" => "top_margin",
					"value" => array(__("None", 'gymbase_trainers') => "none", __("Page (small)", 'gymbase_trainers') => "page-margin-top", __("Section (large)", 'gymbase_trainers') => "page-margin-top-section")
				),
				array(
					'type' => 'textfield',
					'heading' => __('Extra class name', 'gymbase_trainers'),
					'param_name' => 'el_class',
					'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'gymbase_trainers')
				)
			)
		));
	}
}
add_action("init", "gymbase_trainers_vc_init");
?>