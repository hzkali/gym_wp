<?php
/*
Plugin Name: GymBase Theme Classes
Plugin URI: https://1.envato.market/quanticalabs-portfolio
Description: GymBase Theme Classes Plugin
Author: QuanticaLabs
Author URI: https://1.envato.market/quanticalabs
Version: 1.2
Text Domain: gymbase_classes
*/

//translation
function gymbase_classes_load_textdomain()
{
	load_plugin_textdomain("gymbase_classes", false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'gymbase_classes_load_textdomain');
//custom post type - classes
if(is_admin())
{
	function gymbase_classes_admin_menu()
	{
		$permalinks_page = add_submenu_page('edit.php?post_type=classes', __('Permalink', 'gymbase_classes'), __('Permalink', 'gymbase_classes'), 'manage_options', 'classes_permalink', 'gymbase_classes_permalink');
	}
	add_action("admin_menu", "gymbase_classes_admin_menu");
	
	function gymbase_classes_permalink()
	{
		$message = "";
		if(isset($_POST["action"]) && $_POST["action"]=="save_classes_permalink")
			$message = __("Options saved!", "gymbase_classes");
		$classes_permalink = array(
			"slug" => 'classes',
			"label_singular" => __("Class", 'gymbase_classes'),
			"label_plural" => __("Classes", 'gymbase_classes')
		);
		$classes_permalink = array_merge($classes_permalink, (array)get_option("classes_permalink"));
		
		require_once("admin/admin-page-permalink.php");
	}
}
function gymbase_classes_init()
{
	global $blog_id;
	global $wpdb;
	
	$classes_permalink = array(
		"slug" => 'classes',
		"label_singular" => __("Class", 'gymbase_classes'),
		"label_plural" => __("Classes", 'gymbase_classes')
	);
	if(isset($_POST["action"]) && $_POST["action"]=="save_classes_permalink")
	{
		$classes_permalink = array_merge($classes_permalink, (array)get_option("classes_permalink"));
		$slug_old = $classes_permalink["slug"];
		$classes_permalink = array(
			"slug" => (!empty($_POST["slug"]) ? sanitize_title($_POST["slug"]) : "classes"),
			"label_singular" => (!empty($_POST["label_singular"]) ? $_POST["label_singular"] : __("Class", "gymbase_classes")),
			"label_plural" => (!empty($_POST["label_plural"]) ? $_POST["label_plural"] : __("Classes", "gymbase_classes"))
		);
		update_option("classes_permalink", $classes_permalink);
		if($slug_old!=$_POST["slug"])
		{
			delete_option('rewrite_rules');
		}
	}
	$classes_permalink = array_merge($classes_permalink, (array)get_option("classes_permalink"));
	$labels = array(
		'name' => $classes_permalink['label_plural'],
		'singular_name' => $classes_permalink['label_singular'],
		'add_new' => _x('Add New', $classes_permalink["slug"], 'gymbase_classes'),
		'add_new_item' => sprintf(__('Add New %s' , 'gymbase_classes') , $classes_permalink['label_singular']),
		'edit_item' => sprintf(__('Edit %s', 'gymbase_classes'), $classes_permalink['label_singular']),
		'new_item' => sprintf(__('New %s', 'gymbase_classes'), $classes_permalink['label_singular']),
		'all_items' => sprintf(__('All %s', 'gymbase_classes'), $classes_permalink['label_plural']),
		'view_item' => sprintf(__('View %s', 'gymbase_classes'), $classes_permalink['label_singular']),
		'search_items' => sprintf(__('Search %s', 'gymbase_classes'), $classes_permalink['label_plural']),
		'not_found' =>  sprintf(__('No %s found', 'gymbase_classes'), strtolower($classes_permalink['label_plural'])),
		'not_found_in_trash' => sprintf(__('No %s found in Trash', 'gymbase_classes'), strtolower($classes_permalink['label_plural'])), 
		'parent_item_colon' => '',
		'menu_name' => $classes_permalink['label_plural']
	);

	$args = array(  
		"labels" => $labels, 
		"public" => true,  
		"show_ui" => true,  
		"capability_type" => "post",  
		"menu_position" => 20,
		"hierarchical" => false,  
		"rewrite" => array("slug" => $classes_permalink["slug"]),
		"supports" => array("title", "editor", "excerpt", "thumbnail", "page-attributes")  
	);
	register_post_type("classes", $args);
	register_taxonomy("classes_category", array("classes"), array("label" => __("Categories", 'gymbase_classes'), "singular_label" => __("Category", 'gymbase_classes'), "rewrite" => true)); 
	if(get_option("gymbase_class_hours_table_installed") && !get_option("gymbase_class_hours_table_renamed"))
	{
		// CHECK IF OLD TABLE NAME EXISTS AND CHANGE IT TO NEW ONE		
		if($wpdb->query($wpdb->prepare("SHOW TABLES LIKE 'wp_%d_class_hours'", $blog_id)) && ("wp_" . $blog_id . "_")!=($wpdb->prefix) )
		{
			$query = $wpdb->prepare("RENAME TABLE `wp_%d_class_hours` to `".$wpdb->prefix."class_hours` ", $blog_id);
			$wpdb->query($query);
		}
		add_option("gymbase_class_hours_table_renamed", 1);
    }
	if(!get_option("gymbase_class_hours_table_installed"))
	{
		//create custom db table
		$query = "CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."class_hours` (
			`class_hours_id` BIGINT( 20 ) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
			`class_id` BIGINT( 20 ) NOT NULL ,
			`weekday_id` BIGINT( 20 ) NOT NULL ,
			`start` TIME NOT NULL ,
			`end` TIME NOT NULL,
			`tooltip` text NOT NULL,
			`before_hour_text` text NOT NULL,
			`after_hour_text` text NOT NULL,
			`trainers` varchar(255) NOT NULL,
			`category` varchar(255) NOT NULL,
			INDEX ( `class_id` ),
			INDEX ( `weekday_id` )
		) ENGINE = MYISAM DEFAULT CHARSET=utf8;";
		$wpdb->query($query);
		//insert sample data
		$query = "INSERT INTO `".$wpdb->prefix."class_hours` (`class_hours_id`, `class_id`, `weekday_id`, `start`, `end`, `tooltip`, `before_hour_text`, `after_hour_text`, `trainers`, `category`) VALUES
			(129, 33, 40, '07:00:00', '09:00:00', '', '', '', '51', 'Loiselle'),
			(130, 34, 39, '11:00:00', '12:30:00', '', '', '', '51', 'Loiselle'),
			(132, 63, 42, '09:00:00', '12:00:00', '', '', '', '59,57', 'Richardson|Anthony'),
			(133, 63, 43, '09:00:00', '11:00:00', '', '', '', '57', 'Anthony'),
			(134, 63, 39, '09:00:00', '11:00:00', '', '', '', '59', 'Richardson'),
			(135, 63, 43, '11:00:00', '13:00:00', '', '', '', '59', 'Richardson'),
			(136, 63, 44, '09:00:00', '12:00:00', '', '', '', '57', 'Anthony'),
			(137, 704, 44, '09:00:00', '12:00:00', '', '', '', '52', 'Harpaul'),
			(138, 704, 39, '14:00:00', '16:00:00', '', '', '', '965', 'Camarena'),
			(139, 704, 44, '14:00:00', '16:00:00', '', '', '', '482', 'Flynn'),
			(140, 61, 44, '07:00:00', '09:00:00', '', '', '', '482', 'Flynn'),
			(141, 61, 39, '11:00:00', '14:00:00', '', '', '', '482', 'Flynn'),
			(142, 55, 42, '16:00:00', '18:00:00', '', '', '', '59', 'Richardson'),
			(143, 55, 41, '14:00:00', '18:00:00', '', '', '', '52', 'Harpaul'),
			(144, 55, 40, '14:00:00', '17:00:00', '', '', '', '52', 'Harpaul'),
			(145, 55, 44, '16:00:00', '18:00:00', '', '', '', '59', 'Richardson'),
			(146, 34, 41, '14:00:00', '17:00:00', '', '', '', '964', 'Morgan'),
			(147, 34, 38, '11:00:00', '13:00:00', '', '', '', '964', 'Morgan'),
			(149, 33, 42, '14:00:00', '16:00:00', '', '', '', '963', 'Ingram'),
			(150, 33, 41, '11:00:00', '14:00:00', '', '', '', '57', 'Anthony'),
			(152, 33, 43, '07:00:00', '09:00:00', '', '', '', '57,52', 'Anthony|Harpaul');";
		$wpdb->query($query);
		add_option("gymbase_class_hours_table_installed", 1);
		add_option("gymbase_class_hours_table_updated_new", 1);
	}
	else if(!get_option("gymbase_class_hours_table_updated_new"))
	{
		$query = "ALTER TABLE `".$wpdb->prefix."class_hours` 
			ADD `tooltip` TEXT NOT NULL ,
			ADD `before_hour_text` TEXT NOT NULL ,
			ADD `after_hour_text` TEXT NOT NULL ,
			ADD `trainers` VARCHAR( 255 ) NOT NULL ,
			ADD `category` VARCHAR( 255 ) NOT NULL";
		$wpdb->query($query);
		add_option("gymbase_class_hours_table_updated_new", 1);
	}
}  
add_action("init", "gymbase_classes_init"); 

//Adds a box to the right column and to the main column on the Classes edit screens
function gymbase_add_classes_custom_box() 
{
    add_meta_box(
        "class_hours",
        __("Class hours", 'gymbase_classes'),
        "gymbase_inner_classes_custom_box_side",
        "classes",
		"normal"
    );
	add_meta_box( 
        "class_config",
        __("Options", 'gymbase_classes'),
        "gymbase_inner_classes_custom_box_main",
        "classes",
		"normal",
		"high"
    );
}
add_action("add_meta_boxes", "gymbase_add_classes_custom_box");

//get class hour details
function gymbase_get_class_hour_details()
{
	global $blog_id;
	global $wpdb;
	$query = $wpdb->prepare("SELECT * FROM `".$wpdb->prefix."class_hours` AS t1 LEFT JOIN {$wpdb->posts} AS t2 ON t1.weekday_id=t2.ID WHERE t1.class_id='%d' AND t1.class_hours_id='%d'", $_POST["post_id"], $_POST["id"]);
	$class_hour = $wpdb->get_row($query);
	$class_hour->start = date("H:i", strtotime($class_hour->start));
	$class_hour->end = date("H:i", strtotime($class_hour->end));
	echo "class_hour_start" . json_encode($class_hour) . "class_hour_end";
	exit();
}
add_action('wp_ajax_get_class_hour_details', 'gymbase_get_class_hour_details');

// Prints the box content
function gymbase_inner_classes_custom_box_side($post) 
{
	global $blog_id;
	global $wpdb;
	
	//Use nonce for verification
	wp_nonce_field(plugin_basename( __FILE__ ), "gymbase_classes_noncename");

	//The actual fields for data entry
	$query = $wpdb->prepare("SELECT * FROM `".$wpdb->prefix."class_hours` AS t1 LEFT JOIN {$wpdb->posts} AS t2 ON t1.weekday_id=t2.ID WHERE t1.class_id='%d' ORDER BY FIELD(t2.menu_order,2,3,4,5,6,7,1), t1.start, t1.end", $post->ID);
	$class_hours = $wpdb->get_results($query);
	$class_hours_count = count($class_hours);
	
	//get weekdays
	$query = "SELECT ID, post_title FROM {$wpdb->posts}
			WHERE 
			post_type='gymbase_weekdays'
			ORDER BY FIELD(menu_order,2,3,4,5,6,7,1)";
	$weekdays = $wpdb->get_results($query);
	
	echo '
	<ul id="class_hours_list"' . (!$class_hours_count ? ' style="display: none;"' : '') . '>';
		for($i=0; $i<$class_hours_count; $i++)
		{
			//get day by id
			$current_day = get_post($class_hours[$i]->weekday_id);
			echo '<li id="class_hours_' . esc_attr($class_hours[$i]->class_hours_id) . '">' . $current_day->post_title . ' ' . date("H:i", strtotime($class_hours[$i]->start)) . '-' . date("H:i", strtotime($class_hours[$i]->end)) . '<img class="operation_button delete_button" src="' . esc_url(get_template_directory_uri() . '/images/delete.png') . '" alt="del" /><img class="operation_button edit_button" src="' . esc_url(get_template_directory_uri() . '/images/edit.png') . '" alt="edit" /><img class="operation_button edit_hour_class_loader" src="' . esc_url(get_template_directory_uri() . '/admin/images/ajax-loader.gif') . '" alt="loader" />';
			$trainersString = "";
			if($class_hours[$i]->trainers!="")
			{
				query_posts(array( 
					'post__in' => explode(",", $class_hours[$i]->trainers),
					'post_type' => 'trainers',
					'posts_per_page' => '-1',
					'post_status' => 'publish',
					'orderby' => 'post_title', 
					'order' => 'DESC'
				));
				while(have_posts()): the_post();
					$trainersString .= get_the_title() . ", ";
				endwhile;
				if($trainersString!="")
					$trainersString = substr($trainersString, 0, -2);
			}
			if($class_hours[$i]->tooltip!="" || $class_hours[$i]->before_hour_text!="" || $class_hours[$i]->after_hour_text!="" || $trainersString!="" || $class_hours[$i]->category!="")
			{
				echo '<div>';
				if($class_hours[$i]->tooltip!="")
					echo '<br /><strong>' . __('Tooltip', 'gymbase_classes') . ':</strong> ' . $class_hours[$i]->tooltip;
				if($class_hours[$i]->before_hour_text!="")
					echo '<br /><strong>' . __('Before hour text', 'gymbase_classes') . ':</strong> ' . $class_hours[$i]->before_hour_text;
				if($class_hours[$i]->after_hour_text!="")
					echo '<br /><strong>' . __('After hour text', 'gymbase_classes') . ':</strong> ' . $class_hours[$i]->after_hour_text;
				if($trainersString)
					echo '<br /><strong>' . __('Trainers', 'gymbase_classes') . ':</strong> ' . $trainersString;
				if($class_hours[$i]->category!="")
					echo '<br /><strong>' . __('Category', 'gymbase_classes') . ':</strong> ' . $class_hours[$i]->category;
				echo '</div>';
			}
			echo '</li>';
		}
	echo '
	</ul>
	<table id="class_hours_table">
		<tr>
			<td>
				<label for="weekday_id">' . __('Day', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<select name="weekday_id" id="weekday_id">';
				foreach($weekdays as $weekday)
					echo '<option value="' . esc_attr($weekday->ID) . '">' . $weekday->post_title . '</option>';
	echo '		</select>
			</td>
		</tr>
		<tr>
			<td>
				<label for="start_hour">' . __('Start hour', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input size="5" maxlength="5" type="text" id="start_hour" name="start_hour" value="" />
				<span class="description">hh:mm</span>
			</td>
		</tr>
		<tr>
			<td>
				<label for="end_hour">' . __('End hour', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input size="5" maxlength="5" type="text" id="end_hour" name="end_hour" value="" />
				<span class="description">hh:mm</span>
			</td>
		</tr>
		<tr>
			<td>
				<label for="before_hour_text">' . __('Before hour text', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<textarea id="before_hour_text" name="before_hour_text"></textarea>
			</td>
		</tr>
		<tr>
			<td>
				<label for="after_hour_text">' . __('After hour text', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<textarea id="after_hour_text" name="after_hour_text"></textarea>
			</td>
		</tr>
		<tr>
			<td>
				<label for="tooltip">' . __('Tooltip', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<textarea id="tooltip" name="tooltip"></textarea>
			</td>
		</tr>';
		if(wp_count_posts("trainers"))
		{
			echo '
		<tr>
			<td>
				<label for="trainers">' . __('Trainers', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<select id="class_hour_trainers" name="class_hour_trainers[]" multiple="multiple">';
					query_posts(array( 
						'post_type' => 'trainers',
						'posts_per_page' => '-1',
						'post_status' => 'publish',
						'orderby' => 'post_title', 
						'order' => 'DESC'
					));
					while(have_posts()): the_post();
						echo '<option value="' . esc_attr(get_the_ID()) . '"' . (!empty($trainers) && in_array(get_the_ID(), (array)$trainers) ? ' selected="selected"' : '') . '>' . get_the_title() . '</option>';
					endwhile;
			echo '
				</select>
			</td>
		</tr>';
		}
		echo '
		<tr>
			<td>
				<label for="class_hour_category">' . __('Category', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input type="text" id="class_hour_category" name="class_hour_category" value="" />
			</td>
		</tr>
		<tr>
			<td colspan="2" style="text-align: right;">
				<input id="add_class_hours" type="button" class="button" value="' . esc_attr__("Add", 'gymbase_classes') . '" />
			</td>
		</tr>
	</table>
	';
	//Reset Query
	wp_reset_query();
}

function gymbase_inner_classes_custom_box_main($post)
{
	//Use nonce for verification
	wp_nonce_field(plugin_basename( __FILE__ ), "gymbase_classes_noncename");
	
	//The actual fields for data entry
	$trainers = get_post_meta($post->ID, "gymbase_trainers", true);
	echo '
	<table>
		<tr>
			<td>
				<label for="subtitle">' . __('Subtitle', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input class="regular-text" type="text" id="subtitle" name="subtitle" value="' . esc_attr(get_post_meta($post->ID, "gymbase_subtitle", true)) . '" />
			</td>
		</tr>';
		if(wp_count_posts("trainers"))
		{
			echo '
		<tr>
			<td>
				<label for="trainers">' . __('Trainers', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<select id="trainers" name="trainers[]" multiple="multiple">';
					query_posts(array( 
						'post_type' => 'trainers',
						'posts_per_page' => '-1',
						'post_status' => 'publish',
						'orderby' => 'post_title', 
						'order' => 'DESC'
					));
					while(have_posts()): the_post();
						echo '<option value="' . esc_attr(get_the_ID()) . '"' . (in_array(get_the_ID(), (array)$trainers) ? ' selected="selected"' : '') . '>' . get_the_title() . '</option>';
					endwhile;
			echo '
				</select>
			</td>
		</tr>';
		}
		echo '
		<tr>
			<td>
				<label for="color">' . __('Timetable box background color', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input class="regular-text color" type="text" id="color" name="color" value="' . esc_attr(get_post_meta($post->ID, "gymbase_color", true)) . '" data-default-color="FFFFFF" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="text_color">' . __('Timetable box text color', 'gymbase_classes') . ':</label>
			</td>
			<td>
				<input class="regular-text color" type="text" id="text_color" name="text_color" value="' . esc_attr(get_post_meta($post->ID, "gymbase_text_color", true)) . '" data-default-color="FFFFFF" />
			</td>
		</tr>
	</table>';
}

//When the post is saved, saves our custom data
function gymbase_save_classes_postdata($post_id) 
{
	global $blog_id;
	global $wpdb;
	//verify if this is an auto save routine. 
	//if it is our form has not been submitted, so we dont want to do anything
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) 
		return;

	//verify this came from the our screen and with proper authorization,
	//because save_post can be triggered at other times
	if (!isset($_POST['gymbase_classes_noncename']) || !wp_verify_nonce($_POST['gymbase_classes_noncename'], plugin_basename( __FILE__ )))
		return;


	//Check permissions
	if(!current_user_can('edit_post', $post_id))
		return;

	//OK, we're authenticated: we need to find and save the data
	$hours_count = (isset($_POST["weekday_ids"]) ? count($_POST["weekday_ids"]) : 0);
	for($i=0; $i<$hours_count; $i++)
	{
		$query = $wpdb->prepare("INSERT INTO `".$wpdb->prefix."class_hours` VALUES(
			NULL,
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s'
		);", $post_id, $_POST["weekday_ids"][$i], $_POST["start_hours"][$i], $_POST["end_hours"][$i], $_POST["tooltips"][$i], $_POST["before_hour_texts"][$i], $_POST["after_hour_texts"][$i], $_POST["class_hours_trainers"][$i], $_POST["class_hours_category"][$i]);
		$wpdb->query($query);
	}
	//removing data if needed
	$delete_class_hours_ids_count = (isset($_POST["delete_class_hours_ids"]) ? count($_POST["delete_class_hours_ids"]) : 0);
	if($delete_class_hours_ids_count)
		$wpdb->query("DELETE FROM `".$wpdb->prefix."class_hours` WHERE class_hours_id IN(" . implode(",", esc_sql($_POST["delete_class_hours_ids"])) . ");");
	//post meta
	update_post_meta($post_id, "gymbase_subtitle", $_POST["subtitle"]);
	update_post_meta($post_id, "gymbase_trainers", $_POST["trainers"]);
	update_post_meta($post_id, "gymbase_color", $_POST["color"]);
	update_post_meta($post_id, "gymbase_text_color", $_POST["text_color"]);
}
add_action("save_post", "gymbase_save_classes_postdata");

//custom classes items list
function gymbase_classes_edit_columns($columns)
{
	$columns = array(  
		"cb" => "<input type=\"checkbox\" />",  
		"title" => _x('Title', 'post type singular name', 'gymbase_classes'),
		"classes_category" => __('Categories', 'gymbase_classes'),
		"date" => __('Date', 'gymbase_classes')
	);    

	return $columns;  
}  
add_filter("manage_edit-classes_columns", "gymbase_classes_edit_columns"); 

function manage_gymbase_classes_posts_custom_column($column)
{
	global $post;
	switch ($column)  
	{
		case "classes_category":
			$classes_category_list = (array)get_the_terms($post->ID, "classes_category");
			foreach($classes_category_list as $classes_category)
			{
				if(empty($classes_category->slug))
					continue;
				echo '<a href="' . esc_url(admin_url("edit.php?post_type=classes&classes_category=" . $classes_category->slug)) . '">' . $classes_category->name . '</a>' . (end($classes_category_list)!=$classes_category ? ", " : "");;
			}
			break;
	}  
}
add_action("manage_classes_posts_custom_column", "manage_gymbase_classes_posts_custom_column");

//classes sidebar
function gymbase_classes_sidebar($atts)
{
	extract(shortcode_atts(array(
		"order" => "ASC",
		"classes_url" => get_home_url() . "/classes",
		"timetable_url" => get_home_url() . "/timetable",
		"category" => ""		
	), $atts));
	
	query_posts(array(
		'post_type' => 'classes',
		'posts_per_page' => '-1',
		'post_status' => 'publish',
		'orderby' => 'menu_order',
		'order' => $order,
		'classes_category' => $category
	));
	
	$output = '';
	if(have_posts()):
		$output .= '<ul class="accordion accordion-sidebar">';
		while(have_posts()): the_post();
			global $post;
			$output .= '<li>
				<div id="accordion-' . urldecode($post->post_name) . '">
					<h3>' . get_the_title() . '</h3>
					<h5>' . esc_attr(get_post_meta($post->ID, "subtitle", true)) . '</h5>
				</div>
				<div class="clearfix">
					<div class="item_content clearfix">';
						if(has_post_thumbnail())
							$output .= '<a class="thumb_image" href="' . esc_url($classes_url) . '/#' . urldecode($post->post_name) . '" title="' . esc_attr(get_the_title()) . '">
								' . get_the_post_thumbnail(get_the_ID(), "gymbase-small-thumb", array("alt" => get_the_title(), "title" => "")) . '
							</a>';
			$output .= '<div class="text">
							' . get_the_excerpt() . '
						</div>
					</div>
					<div class="item_footer clearfix">
						<a class="more icon_small_arrow margin_right_white" href="' . esc_url($classes_url) . '/#' . urldecode($post->post_name) . '" title="' . esc_attr__("Details", 'gymbase_classes') . '">' . __("Details", 'gymbase_classes') . '</a>
						<a class="more icon_small_arrow margin_right_white" href="' . esc_url($timetable_url) . '/#' . urldecode($post->post_name) . '" title="' . esc_attr__("Timetable", 'gymbase_classes') . '">' . __("Timetable", 'gymbase_classes') . '</a>
					</div>
				</div>
			</li>';
		endwhile;
		$output .= '</ul>';
	endif;
	
	return $output;
}
add_shortcode("classes_sidebar", "gymbase_classes_sidebar");

//classes shortcode
function gymbase_classes($atts)
{
	extract(shortcode_atts(array(
		"order_by" => "menu_order",
		"order" => "ASC",
		"timetable_url" => get_home_url() . "/timetable",
		"category" => "",
		"top_margin" => "none",
		"about_button" => 1,
		"trainers_button" => 1,
		"timetable_button" => 1
	), $atts));
	
	/*query_posts(array( 
		'post_type' => 'classes',
		'posts_per_page' => '-1',
		'post_status' => 'publish',
		'orderby' => $order_by, 
		'order' => $order,
		'classes_category' => $category
	));*/
	
	$posts_list = get_posts(array(
		'post_type' => 'classes',
		'posts_per_page' => '-1',
		'post_status' => 'publish',
		'orderby' => $order_by, 
		'order' => $order,
		'classes_category' => $category
	));


	$controls = (($about_button && $trainers_button) || ($timetable_button && ($about_button || $trainers_button)) ? 1 : 0);
	$output = '';
	//if(have_posts()):
	if(count($posts_list))
	{
		$output .= '<ul class="classes-accordion accordion' . ($top_margin!="none" ? ' ' . esc_attr($top_margin) : '') . (!$controls ? ' full-width' : '') . '">';
		global $post;
		$currentPost = $post;
		foreach($posts_list as $post) 
		{
		//while(have_posts()): the_post();
			
			setup_postdata($post);
			$trainers = array_values(array_filter((array)get_post_meta(get_the_ID(), "gymbase_trainers", true)));
			$output .= '<li>
				<div id="accordion-' . urldecode($post->post_name) . '" class="template-arrow-vertical-4-after">
					<h5>' . get_the_title() . '</h5>
					<p class="gb-subtitle">' . esc_attr(get_post_meta(get_the_ID(), "gymbase_subtitle", true)) . '</p>
				</div>
				<div class="clearfix ' . ($controls ? 'tabs' : '') . '">';
			if($controls):
			$output .= '<ul>';
					if($about_button):
					$output .= '
					<li>
						<a href="#' . urldecode($post->post_name) . '-about" title="' . esc_attr__("About", 'gymbase_classes') . '">' . __("ABOUT", 'gymbase_classes') . '</a>
					</li>';
					endif;
					if(count($trainers) && $trainers_button):
					$output .= '
					<li>
						<a href="#' . urldecode($post->post_name) . '-trainers" title="' . esc_attr__("Trainers", 'gymbase_classes') . '">' . __("TRAINERS", 'gymbase_classes') . '</a>
					</li>';
					endif;
					if($timetable_button):
					$output .= '
					<li>
						<a href="' . esc_url($timetable_url) . '/#' . urldecode($post->post_name) . '" title="' . esc_attr__("Timetable", 'gymbase_classes') . '">' . __("TIMETABLE", 'gymbase_classes') . '</a>
					</li>';
					endif;
				$output .= '</ul>';
			endif;	
					
					if($about_button):
						$output .= '<div id="' . urldecode($post->post_name) . '-about" class="tabs-panel">';
							if(has_post_thumbnail())
								$output .= get_the_post_thumbnail(get_the_ID(), "blog-post-thumb", array("alt" => get_the_title(), "title" => "", "class" => "about-img"));
					$output .= do_shortcode( get_the_content()) . '
						</div>';
					endif;
				if(count($trainers) && $trainers_button)
				{
					$output .= '<div id="' . urldecode($post->post_name) . '-trainers" class="tabs-panel">' . do_shortcode('[trainers ids="' . implode(",", (array)$trainers) . '" type="details" image_box_link="1" display_headers="1" load_content_description="0"]') . '</div>';
				}
				$output .= '
				</div>
			</li>';
		}
		$post = $currentPost;
		//endwhile;
		$output .= '</ul>';
	}
	else
	{
		$output .= __("No Classes available", 'gymbase_classes');
	}
	//endif;
	
	//Reset Query
	wp_reset_query();
	return $output;
}
add_shortcode("classes", "gymbase_classes");

//classes list
function gymbase_classes_list($atts)
{
	$atts["type"] = "list";
	$atts["layout"] = "gallery-3-columns";
	$atts["layout_type"] = "separate";
	return gymbase_gallery_shortcode($atts, '', "classes");
}
add_shortcode("classes_list", "gymbase_classes_list");

//visual composer
function gymbase_classes_vc_init()
{
	if(is_plugin_active("js_composer/js_composer.php") && function_exists('vc_map'))
	{
		//get classes list
		$classes_list = get_posts(array(
			'posts_per_page' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
			'post_type' => 'classes'
		));
		$classes_array = array();
		$classes_array[__("All", 'gymbase_classes')] = "-";
		foreach($classes_list as $class)
			$classes_array[$class->post_title . " (id:" . $class->ID . ")"] = $class->ID;

		//get categories list
		$categories = get_terms("classes_category");
		$categories_array = array();
		$categories_array[__("All", 'gymbase_classes')] = "";
		foreach($categories as $category) {
			$categories_array[$category->name] = $category->slug;
		}
		//get all pages
		$timetable_page = get_page_by_title("timetable");	
		$pages_list = get_posts(array(
			'posts_per_page' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
			'post_type' => 'page',
			'post__not_in' => !empty($timetable_page->ID) ?  array($timetable_page->ID) : ''
		));
		if(!empty($timetable_page)) {
			array_unshift($pages_list, $timetable_page);
		}
		$pages_array = array();
		foreach($pages_list as $page)
			$pages_array[$page->post_title . " (id:" . $page->ID . ")"] = home_url() . "/" . $page->post_name;
		
		vc_map( array(
			"name" => __("Classes Accordion [deprecated]", 'gymbase_classes'),
			"base" => "classes",
			"class" => "",
			"controls" => "full",
			"show_settings_on_create" => true,
			"icon" => "icon-wpb-ui-accordion",
			"category" => __('GymBase', 'gymbase_classes'),
			"deprecated" => "6.1",
			"params" => array(
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Category", 'gymbase_classes'),
					"param_name" => "category",
					"value" => $categories_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("About button", 'gymbase_classes'),
					"param_name" => "about_button",
					"value" => array(__("Enable", 'gymbase_classes') => 1, __("Disable", 'gymbase_classes') => 0)
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Trainers button", 'gymbase_classes'),
					"param_name" => "trainers_button",
					"value" => array(__("Enable", 'gymbase_classes') => 1, __("Disable", 'gymbase_classes') => 0)
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Timetable button", 'gymbase_classes'),
					"param_name" => "timetable_button",
					"value" => array(__("Enable", 'gymbase_classes') => 1, __("Disable", 'gymbase_classes') => 0),
					"description" => "Button won't be visible, if both About and Trainers buttons are disabled"
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Timetable page", 'gymbase_classes'),
					"param_name" => "timetable_url",
					"value" => $pages_array				
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order by", 'gymbase_classes'),
					"param_name" => "order_by",
					"value" => array(__("Menu order", 'gymbase_classes') => "menu_order", __("Title", 'gymbase_classes') => "title" )
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order", 'gymbase_classes'),
					"param_name" => "order",
					"value" => array(__("ASC", 'gymbase_classes') => "asc", __("DESC", 'gymbase_classes') => "desc" )
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Top margin", 'gymbase_classes'),
					"param_name" => "top_margin",
					"value" => array(__("None", 'gymbase_classes') => "none", __("Page (small)", 'gymbase_classes') => "page-margin-top", __("Section (large)", 'gymbase_classes') => "page-margin-top-section")
				)
			)
		));
		vc_map( array(
			"name" => __("Classes list", 'gymbase_classes'),
			"base" => "classes_list",
			"class" => "",
			"controls" => "full",
			"show_settings_on_create" => true,
			"icon" => "icon-wpb-layer-custom-post-type-list",
			"category" => __('GymBase', 'gymbase_classes'),
			"params" => array(
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Display method", 'gymbase_classes'),
					"param_name" => "display_method",
					"value" => array(__("Simple", 'gymbase_classes') => 'dm_simple', __("Carousel", 'gymbase_classes') => 'dm_carousel')
				),
				//carousel options
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("Id", 'gymbase_classes'),
					"param_name" => "id",
					"value" => "carousel",
					"description" => __("Please provide unique id for each carousel on the same page/post", 'gymbase_classes'),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Autoplay", 'gymbase_classes'),
					"param_name" => "autoplay",
					"value" => array(__("No", 'gymbase_classes') => 0, __("Yes", 'gymbase_classes') => 1),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Pause on hover", 'gymbase_classes'),
					"param_name" => "pause_on_hover",
					"value" => array(__("Yes", 'gymbase_classes') => 1, __("No", 'gymbase_classes') => 0),
					"description" => __("Affect only when autoplay is set to yes", 'gymbase_classes'),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("Scroll", 'gymbase_classes'),
					"param_name" => "scroll",
					"value" => 1,
					"description" => __("Number of items to scroll in one step", 'gymbase_classes'),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Effect", 'gymbase_classes'),
					"param_name" => "effect",
					"value" => array(
						__("scroll", 'gymbase_classes') => "scroll", 
						__("none", 'gymbase_classes') => "none", 
						__("directscroll", 'gymbase_classes') => "directscroll",
						__("fade", 'gymbase_classes') => "_fade",
						__("crossfade", 'gymbase_classes') => "crossfade",
						__("cover", 'gymbase_classes') => "cover",
						__("uncover", 'gymbase_classes') => "uncover"
					),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Sliding easing", 'gymbase_classes'),
					"param_name" => "easing",
					"value" => array(
						__("swing", 'gymbase_classes') => "swing", 
						__("linear", 'gymbase_classes') => "linear", 
						__("easeInQuad", 'gymbase_classes') => "easeInQuad",
						__("easeOutQuad", 'gymbase_classes') => "easeOutQuad",
						__("easeInOutQuad", 'gymbase_classes') => "easeInOutQuad",
						__("easeInCubic", 'gymbase_classes') => "easeInCubic",
						__("easeOutCubic", 'gymbase_classes') => "easeOutCubic",
						__("easeInOutCubic", 'gymbase_classes') => "easeInOutCubic",
						__("easeInQuart", 'gymbase_classes') => "easeInQuart",
						__("easeOutQuart", 'gymbase_classes') => "easeOutQuart",
						__("easeInOutQuart", 'gymbase_classes') => "easeInOutQuart",
						__("easeInSine", 'gymbase_classes') => "easeInSine",
						__("easeOutSine", 'gymbase_classes') => "easeOutSine",
						__("easeInOutSine", 'gymbase_classes') => "easeInOutSine",
						__("easeInExpo", 'gymbase_classes') => "easeInExpo",
						__("easeOutExpo", 'gymbase_classes') => "easeOutExpo",
						__("easeInOutExpo", 'gymbase_classes') => "easeInOutExpo",
						__("easeInQuint", 'gymbase_classes') => "easeInQuint",
						__("easeOutQuint", 'gymbase_classes') => "easeOutQuint",
						__("easeInOutQuint", 'gymbase_classes') => "easeInOutQuint",
						__("easeInCirc", 'gymbase_classes') => "easeInCirc",
						__("easeOutCirc", 'gymbase_classes') => "easeOutCirc",
						__("easeInOutCirc", 'gymbase_classes') => "easeInOutCirc",
						__("easeInElastic", 'gymbase_classes') => "easeInElastic",
						__("easeOutElastic", 'gymbase_classes') => "easeOutElastic",
						__("easeInOutElastic", 'gymbase_classes') => "easeInOutElastic",
						__("easeInBack", 'gymbase_classes') => "easeInBack",
						__("easeOutBack", 'gymbase_classes') => "easeOutBack",
						__("easeInOutBack", 'gymbase_classes') => "easeInOutBack",
						__("easeInBounce", 'gymbase_classes') => "easeInBounce",
						__("easeOutBounce", 'gymbase_classes') => "easeOutBounce",
						__("easeInOutBounce", 'gymbase_classes') => "easeInOutBounce"
					),
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("Sliding transition speed (ms)", 'gymbase_classes'),
					"param_name" => "duration",
					"value" => 500,
					"dependency" => Array('element' => "display_method", 'value' => 'dm_carousel')
				),
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Display selected", 'gymbase_trainers'),
					"param_name" => "ids",
					"value" => $classes_array
				),
				array(
					"type" => "dropdownmulti",
					"class" => "",
					"heading" => __("Category", 'gymbase_classes'),
					"param_name" => "category",
					"value" => $categories_array
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order by", 'gymbase_classes'),
					"param_name" => "order_by",
					"value" => array(__("Menu order", 'gymbase_classes') => "menu_order", __("Title", 'gymbase_classes') => "title" )
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Order", 'gymbase_classes'),
					"param_name" => "order",
					"value" => array(__("ASC", 'gymbase_classes') => "asc", __("DESC", 'gymbase_classes') => "desc" )
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Link to single gallery page on image box", 'gymbase_classes'),
					"param_name" => "image_box_link",
					"value" => array(__("Yes", 'gymbase_classes') => 1, __("No", 'gymbase_classes') => 0)
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("Extra class name", 'ql_projects'),
					"param_name" => "el_class",
					"value" => ""
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => __("Top margin", 'gymbase_classes'),
					"param_name" => "top_margin",
					"value" => array(__("None", 'gymbase_classes') => "none", __("Page (small)", 'gymbase_classes') => "page-margin-top", __("Section (large)", 'gymbase_classes') => "page-margin-top-section")
				)
			)
		));
	}
}
add_action("init", "gymbase_classes_vc_init");

//custom post type - weekdays
function gymbase_weekdays_init()
{
	$labels = array(
		'name' => _x('Weekdays', 'post type general name', 'gymbase_classes'),
		'singular_name' => _x('Day', 'post type singular name', 'gymbase_classes'),
		'add_new' => _x('Add New', 'gymbase_weekdays', 'gymbase_classes'),
		'add_new_item' => __('Add New Day', 'gymbase_classes'),
		'edit_item' => __('Edit Day', 'gymbase_classes'),
		'new_item' => __('New Day', 'gymbase_classes'),
		'all_items' => __('All Weekdays', 'gymbase_classes'),
		'view_item' => __('View Day', 'gymbase_classes'),
		'search_items' => __('Search Weekdays', 'gymbase_classes'),
		'not_found' =>  __('No weekdays found', 'gymbase_classes'),
		'not_found_in_trash' => __('No weekdays found in Trash', 'gymbase_classes'), 
		'parent_item_colon' => '',
		'menu_name' => __("Weekdays", 'gymbase_classes')
	);
	$args = array(  
		"labels" => $labels, 
		"public" => true,  
		"show_ui" => true,  
		"capability_type" => "post",  
		"menu_position" => 20,
		"hierarchical" => false,  
		"rewrite" => true,  
		"supports" => array("title", "page-attributes")
	);
	register_post_type("gymbase_weekdays", $args);
}  
add_action("init", "gymbase_weekdays_init"); 

//custom weekdays items list
function gymbase_weekdays_edit_columns($columns)
{
	$columns = array(  
		"cb" => "<input type=\"checkbox\" />",  
		"title" => _x('Day name', 'post type singular name', 'gymbase_classes'),   
		"date" => __('Date', 'gymbase_classes')
	);    

	return $columns;  
}  
add_filter("manage_edit-gymbase_weekdays_columns", "gymbase_weekdays_edit_columns");
?>