<?php
/*
Plugin Name: GymBase Theme Shortcodes
Plugin URI: https://1.envato.market/quanticalabs-portfolio
Description: GymBase Theme Shortcodes plugin
Author: QuanticaLabs
Author URI: https://1.envato.market/quanticalabs
Version: 1.2
*/

//shortcodes
function gymbase_shortcodes_vc_init()
{
	if(function_exists("vc_map"))
	{
		add_shortcode("gb_cart_icon", "gb_theme_cart_icon");
		add_shortcode("gb_icon", "gb_theme_icon");
		add_shortcode("items_list", "gb_theme_items_list");
		add_shortcode("item", "gb_theme_item");
		add_shortcode("blog", "gb_theme_blog");
		add_shortcode("single_post", "gb_theme_single_post");
		add_shortcode("single_trainer", "gb_theme_single_trainer");
		add_shortcode("single_class", "gb_theme_single_class");
		add_shortcode("single_gallery", "gb_theme_single_gymbase_gallery");
		add_shortcode("comments", "gb_theme_comments");
		add_shortcode("featured_item", "gb_theme_featured_item");
		add_shortcode("timeline_item", "gb_theme_timeline_item");
		add_shortcode("timeline_carousel", "gb_theme_timeline_carousel");
		add_shortcode("single_page_link", "single_page_link");
		add_shortcode("counter_box", "gb_theme_counter_box");
		add_shortcode("timetable", "gb_theme_timetable");
		add_shortcode("gymbase_map", "gb_theme_map_shortcode");
		add_shortcode("gymbase_contact_form", "gb_theme_contact_form_shortcode");
		add_shortcode("contact_details", "gb_theme_contact_details"); //deprecated
		add_shortcode("contact_info", "gb_theme_contact_info");
		add_shortcode("contact_info_vc", "gb_theme_contact_info_vc");
		add_shortcode("list_pages", "gb_theme_list_pages");
		add_shortcode("show_all_button", "gb_theme_show_all_button");
		add_shortcode("info_text", "gb_theme_info_text");
		add_shortcode("box_header", "gb_theme_box_header");
		add_shortcode("gb_testimonials", "gb_theme_testimonials_shortcode");
		add_shortcode("slider", "gb_theme_slider");
		add_shortcode("slider_content", "gb_theme_slider_content");
		if(function_exists("vc_add_shortcode_param"))
		{
			vc_add_shortcode_param('dropdownmulti' , 'gb_dropdownmultiple_settings_field');
			vc_add_shortcode_param('hidden', 'gb_hidden_settings_field');
			vc_add_shortcode_param('readonly', 'gb_readonly_settings_field');
			vc_add_shortcode_param('listitem' , 'gb_listitem_settings_field');
			vc_add_shortcode_param('listitemwindow' , 'gb_listitemwindow_settings_field');
		}
	}
}
add_action("init", "gymbase_shortcodes_vc_init");
?>